# Restoran Lezat 🍽️

Website sederhana untuk menampilkan menu makanan restoran.

## Fitur
- Tampilan responsif
- Menu makanan bergambar
- Informasi kontak dan profil restoran

## Dibuat oleh
[irrgi.github.io](https://irrgi.github.io)
